package com.expressive.keyboard

import org.junit.Assert.assertEquals
import org.junit.Test

/** Telex: вьетнамский набирается как раньше, а английские слова не превращаются в «clipbỏad». */
class TelexTest {
    @Test
    fun vietnameseStillComposes() {
        mapOf(
        "nguwowif" to "người",
        "dduwowcj" to "được",
        "nuwowcs" to "nước",
        "tieengs" to "tiếng",
        "vieetj" to "việt",
        "truwowngf" to "trường",
        "giuwowngf" to "giường",
        "quar" to "quả",
        "gif" to "gì",
        "giuwx" to "giữ",
        "ngoaif" to "ngoài",
        "tuooir" to "tuổi",
        "muwowif" to "mười",
        "ruwowuj" to "rượu",
        "yeeu" to "yêu",
        "khuyeen" to "khuyên",
        "hoaf" to "hòa",
        "queen" to "quên",
        "nguyeenx" to "nguyễn",
        "Hoangf" to "Hoàng",
        "Dduwcs" to "Đức",
            "toans" to "toán", "hoaf" to "hòa", "viee" to "viê"
        ).forEach { (typed, word) -> assertEquals(typed, word, Telex.compose(typed)) }
    }

    @Test
    fun englishWordsStayAsTyped() {
        listOf("clipboard", "keyboard", "window", "text", "school", "pizza", "issue", "ass", "addition", "it's", "program")
            .forEach { assertEquals(it, it, Telex.compose(it)) }
    }
}
